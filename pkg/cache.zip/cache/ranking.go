package cache

import (
	"context"
	"lotteryBackend/global"
)

func ClearRoundScores(roundId uint) error {
	ctx := context.Background()
	key := GetRoundScoresKey(roundId)
	return global.GVA_REDIS.Del(ctx, key).Err()
}

// ClearRoundInfo 清除场次信息
func ClearRoundInfo(roundId uint) error {
	ctx := context.Background()
	key := GetRoundInfoKey(roundId)
	return global.GVA_REDIS.Del(ctx, key).Err()
}

// ClearRoundStatus 清除场次状态
func ClearRoundStatus(roundId uint) error {
	ctx := context.Background()
	key := GetRoundStatusKey(roundId)
	return global.GVA_REDIS.Del(ctx, key).Err()
}

// ClearRoundAll 清除场次所有缓存
func ClearRoundAll(roundId uint) error {
	ctx := context.Background()
	keys := []string{
		GetRoundScoresKey(roundId),
		GetRoundInfoKey(roundId),
		GetRoundStatusKey(roundId),
	}
	return global.GVA_REDIS.Del(ctx, keys...).Err()
}
